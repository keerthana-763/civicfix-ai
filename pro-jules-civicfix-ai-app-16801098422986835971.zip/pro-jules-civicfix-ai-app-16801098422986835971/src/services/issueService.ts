import type { Issue, IssueCategory, IssuePriority, IssueStatus } from '../types/issue';
import { INITIAL_ISSUES } from '../data/mockIssues';

const STORAGE_KEY = 'civicfix_ai_issues_v1';

export const issueService = {
  getIssues(): Issue[] {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_ISSUES));
      return INITIAL_ISSUES;
    }
    try {
      return JSON.parse(data);
    } catch {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_ISSUES));
      return INITIAL_ISSUES;
    }
  },

  getIssueById(id: string): Issue | undefined {
    const issues = this.getIssues();
    return issues.find((issue) => issue.id === id);
  },

  createIssue(newIssueData: {
    title: string;
    category: IssueCategory;
    description: string;
    location: string;
    priority: IssuePriority;
    reportedBy?: string;
    aiTag?: string;
    aiConfidence?: number;
    aiSuggestedDepartment?: string;
  }): Issue {
    const issues = this.getIssues();
    const count = issues.length + 1;
    const padNum = String(count).padStart(3, '0');
    const now = new Date().toISOString();

    const newIssue: Issue = {
      id: `CF-2026-${padNum}`,
      title: newIssueData.title,
      category: newIssueData.category,
      description: newIssueData.description,
      location: newIssueData.location,
      priority: newIssueData.priority,
      status: 'Reported',
      createdAt: now,
      updatedAt: now,
      reportedBy: newIssueData.reportedBy || 'Anonymous Resident',
      upvotes: 1,
      aiTag: newIssueData.aiTag || 'Automated Categorization',
      aiConfidence: newIssueData.aiConfidence || 92,
      aiSuggestedDepartment: newIssueData.aiSuggestedDepartment || 'General Municipal Services',
      timeline: [
        {
          id: `t-${Date.now()}`,
          status: 'Reported',
          timestamp: now,
          note: 'Issue submitted and logged into CivicFix AI system.',
        },
      ],
    };

    const updated = [newIssue, ...issues];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return newIssue;
  },

  updateStatus(id: string, newStatus: IssueStatus, note?: string): Issue | null {
    const issues = this.getIssues();
    const index = issues.findIndex((i) => i.id === id);
    if (index === -1) return null;

    const currentIssue = issues[index];
    const now = new Date().toISOString();

    const updatedTimelineNote =
      note ||
      (newStatus === 'In Progress'
        ? 'Assigned to specialized response team. Maintenance underway.'
        : newStatus === 'Resolved'
        ? 'Resolution verified and closed by community supervisor.'
        : 'Status set back to reported.');

    const updatedIssue: Issue = {
      ...currentIssue,
      status: newStatus,
      updatedAt: now,
      timeline: [
        ...currentIssue.timeline,
        {
          id: `t-${Date.now()}`,
          status: newStatus,
          timestamp: now,
          note: updatedTimelineNote,
        },
      ],
    };

    issues[index] = updatedIssue;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(issues));
    return updatedIssue;
  },

  upvoteIssue(id: string): Issue | null {
    const issues = this.getIssues();
    const index = issues.findIndex((i) => i.id === id);
    if (index === -1) return null;

    const updatedIssue = {
      ...issues[index],
      upvotes: issues[index].upvotes + 1,
    };

    issues[index] = updatedIssue;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(issues));
    return updatedIssue;
  },

  resetToMockData(): Issue[] {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_ISSUES));
    return INITIAL_ISSUES;
  },

  // AI Assistant logic to auto detect category and priority based on input text
  analyzeIssueText(text: string): {
    category: IssueCategory;
    priority: IssuePriority;
    confidence: number;
    suggestedDepartment: string;
    aiTag: string;
  } {
    const lower = text.toLowerCase();

    if (
      lower.includes('trash') ||
      lower.includes('garbage') ||
      lower.includes('waste') ||
      lower.includes('smell') ||
      lower.includes('bin') ||
      lower.includes('dump')
    ) {
      return {
        category: 'Garbage Overflow',
        priority: lower.includes('urgent') || lower.includes('block') ? 'High' : 'Medium',
        confidence: 95,
        suggestedDepartment: 'Campus Sanitation & Waste Mgmt',
        aiTag: 'Sanitation Alert',
      };
    }

    if (
      lower.includes('water') ||
      lower.includes('pipe') ||
      lower.includes('leak') ||
      lower.includes('burst') ||
      lower.includes('drain') ||
      lower.includes('overflowing tap')
    ) {
      return {
        category: 'Water Leakage',
        priority: lower.includes('burst') || lower.includes('flooding') ? 'Urgent' : 'High',
        confidence: 96,
        suggestedDepartment: 'Plumbing & Municipal Utilities',
        aiTag: 'Utility Breakdown',
      };
    }

    if (
      lower.includes('light') ||
      lower.includes('dark') ||
      lower.includes('lamp') ||
      lower.includes('flicker') ||
      lower.includes('electricity') ||
      lower.includes('wire')
    ) {
      return {
        category: 'Broken Streetlights',
        priority: lower.includes('night') || lower.includes('wire') ? 'High' : 'Medium',
        confidence: 93,
        suggestedDepartment: 'Electrical & Street Lighting Maintenance',
        aiTag: 'Public Safety Hazard',
      };
    }

    if (
      lower.includes('road') ||
      lower.includes('pothole') ||
      lower.includes('crack') ||
      lower.includes('asphalt') ||
      lower.includes('pavement') ||
      lower.includes('footpath')
    ) {
      return {
        category: 'Damaged Roads',
        priority: lower.includes('deep') || lower.includes('accident') ? 'High' : 'Medium',
        confidence: 94,
        suggestedDepartment: 'Civil Works & Road Repairs',
        aiTag: 'Road Infrastructure',
      };
    }

    if (
      lower.includes('restroom') ||
      lower.includes('toilet') ||
      lower.includes('facility') ||
      lower.includes('dirty') ||
      lower.includes('soap') ||
      lower.includes('washroom')
    ) {
      return {
        category: 'Unclean Public Facilities',
        priority: 'Medium',
        confidence: 90,
        suggestedDepartment: 'Housekeeping & Campus Maintenance',
        aiTag: 'Hygiene & Housekeeping',
      };
    }

    return {
      category: 'Other',
      priority: lower.includes('urgent') || lower.includes('danger') ? 'High' : 'Low',
      confidence: 82,
      suggestedDepartment: 'General Community Support',
      aiTag: 'Community Feedback',
    };
  },
};
