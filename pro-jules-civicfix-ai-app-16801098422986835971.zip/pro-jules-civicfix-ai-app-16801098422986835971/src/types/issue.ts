export type IssueCategory =
  | 'Garbage Overflow'
  | 'Water Leakage'
  | 'Broken Streetlights'
  | 'Damaged Roads'
  | 'Unclean Public Facilities'
  | 'Public Safety'
  | 'Other';

export type IssuePriority = 'Low' | 'Medium' | 'High' | 'Urgent';

export type IssueStatus = 'Reported' | 'In Progress' | 'Resolved';

export interface TimelineEvent {
  id: string;
  status: IssueStatus;
  timestamp: string;
  note: string;
}

export interface Issue {
  id: string;
  title: string;
  category: IssueCategory;
  description: string;
  location: string;
  priority: IssuePriority;
  status: IssueStatus;
  createdAt: string;
  updatedAt: string;
  reportedBy: string;
  upvotes: number;
  aiTag?: string;
  aiConfidence?: number;
  aiSuggestedDepartment?: string;
  timeline: TimelineEvent[];
}
