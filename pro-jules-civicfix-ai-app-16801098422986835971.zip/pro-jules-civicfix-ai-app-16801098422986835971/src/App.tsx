import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomeView } from './components/HomeView';
import { ReportIssueView } from './components/ReportIssueView';
import { ViewIssuesView } from './components/ViewIssuesView';
import { DashboardView } from './components/DashboardView';
import type { Issue, IssueStatus } from './types/issue';
import { issueService } from './services/issueService';

export function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'report' | 'issues' | 'dashboard'>('home');
  const [issues, setIssues] = useState<Issue[]>([]);

  // Load issues on initial mount
  useEffect(() => {
    const loaded = issueService.getIssues();
    setIssues(loaded);
  }, []);

  const handleIssueSubmitted = (newIssue: Issue) => {
    setIssues((prev) => [newIssue, ...prev]);
  };

  const handleStatusChange = (id: string, newStatus: IssueStatus) => {
    const updated = issueService.updateStatus(id, newStatus);
    if (updated) {
      setIssues((prev) => prev.map((item) => (item.id === id ? updated : item)));
    }
  };

  const handleUpvote = (id: string) => {
    const updated = issueService.upvoteIssue(id);
    if (updated) {
      setIssues((prev) => prev.map((item) => (item.id === id ? updated : item)));
    }
  };

  const handleResetData = () => {
    const reset = issueService.resetToMockData();
    setIssues(reset);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} issueCount={issues.length} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-16">
        {activeTab === 'home' && (
          <HomeView issues={issues} setActiveTab={setActiveTab} />
        )}

        {activeTab === 'report' && (
          <ReportIssueView
            onIssueSubmitted={handleIssueSubmitted}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'issues' && (
          <ViewIssuesView
            issues={issues}
            onStatusChange={handleStatusChange}
            onUpvote={handleUpvote}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'dashboard' && (
          <DashboardView
            issues={issues}
            onStatusChange={handleStatusChange}
            setActiveTab={setActiveTab}
            onResetData={handleResetData}
          />
        )}
      </main>

      <Footer setActiveTab={setActiveTab} />
    </div>
  );
}

export default App;
