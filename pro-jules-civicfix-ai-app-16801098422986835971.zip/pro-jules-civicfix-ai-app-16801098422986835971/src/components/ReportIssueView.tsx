import React, { useState, useEffect } from 'react';
import {
  PlusCircle,
  Sparkles,
  MapPin,
  CheckCircle2,
  ListFilter,
  HelpCircle,
  Building,
} from 'lucide-react';
import type { IssueCategory, IssuePriority, Issue } from '../types/issue';
import { issueService } from '../services/issueService';

interface ReportIssueViewProps {
  onIssueSubmitted: (newIssue: Issue) => void;
  setActiveTab: (tab: 'home' | 'report' | 'issues' | 'dashboard') => void;
}

export const ReportIssueView: React.FC<ReportIssueViewProps> = ({
  onIssueSubmitted,
  setActiveTab,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<IssueCategory>('Garbage Overflow');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [priority, setPriority] = useState<IssuePriority>('Medium');
  const [reporterName, setReporterName] = useState('');

  // AI Assistant Analysis State
  const [aiSuggestion, setAiSuggestion] = useState<{
    category: IssueCategory;
    priority: IssuePriority;
    confidence: number;
    suggestedDepartment: string;
    aiTag: string;
  } | null>(null);

  // Form Validation Errors
  const [errors, setErrors] = useState<{
    title?: string;
    description?: string;
    location?: string;
  }>({});

  // Submission Status State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedIssue, setSubmittedIssue] = useState<Issue | null>(null);

  // Trigger AI Auto-classification on text change
  useEffect(() => {
    const text = `${title} ${description}`.trim();
    if (text.length > 8) {
      const result = issueService.analyzeIssueText(text);
      setAiSuggestion(result);
    } else {
      setAiSuggestion(null);
    }
  }, [title, description]);

  const applyAiSuggestion = () => {
    if (aiSuggestion) {
      setCategory(aiSuggestion.category);
      setPriority(aiSuggestion.priority);
    }
  };

  const validateForm = () => {
    const newErrors: { title?: string; description?: string; location?: string } = {};

    if (!title.trim()) {
      newErrors.title = 'Issue title is required.';
    } else if (title.trim().length < 5) {
      newErrors.title = 'Title must be at least 5 characters long.';
    }

    if (!location.trim()) {
      newErrors.location = 'Please specify the exact location or landmark.';
    }

    if (!description.trim()) {
      newErrors.description = 'Detailed description is required to help maintenance teams.';
    } else if (description.trim().length < 15) {
      newErrors.description = 'Please provide a bit more detail (at least 15 characters).';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsSubmitting(true);

    setTimeout(() => {
      const created = issueService.createIssue({
        title: title.trim(),
        category,
        description: description.trim(),
        location: location.trim(),
        priority,
        reportedBy: reporterName.trim() || 'Anonymous Student / Resident',
        aiTag: aiSuggestion?.aiTag,
        aiConfidence: aiSuggestion?.confidence,
        aiSuggestedDepartment: aiSuggestion?.suggestedDepartment,
      });

      setIsSubmitting(false);
      setSubmittedIssue(created);
      onIssueSubmitted(created);
    }, 600);
  };

  const resetForm = () => {
    setTitle('');
    setCategory('Garbage Overflow');
    setDescription('');
    setLocation('');
    setPriority('Medium');
    setReporterName('');
    setSubmittedIssue(null);
    setErrors({});
  };

  const categories: IssueCategory[] = [
    'Garbage Overflow',
    'Water Leakage',
    'Broken Streetlights',
    'Damaged Roads',
    'Unclean Public Facilities',
    'Public Safety',
    'Other',
  ];

  const priorities: IssuePriority[] = ['Low', 'Medium', 'High', 'Urgent'];

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm">
        <div className="flex items-center space-x-3 mb-2">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
            <PlusCircle className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Report a Community Issue</h1>
            <p className="text-sm text-slate-500">
              Submit problems directly to campus and municipal maintenance departments.
            </p>
          </div>
        </div>
      </div>

      {/* Success Modal / State */}
      {submittedIssue ? (
        <div className="bg-white p-8 rounded-2xl border border-emerald-200 shadow-xl space-y-6 text-center animate-fadeIn">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="inline-block px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-semibold rounded-full border border-emerald-200">
              Report Submitted Successfully
            </span>
            <h2 className="text-2xl font-extrabold text-slate-900">Issue #{submittedIssue.id}</h2>
            <p className="text-slate-600 text-sm max-w-md mx-auto">
              Thank you! Your report has been logged into the CivicFix AI network and dispatched to{' '}
              <span className="font-semibold text-slate-800">{submittedIssue.aiSuggestedDepartment}</span>.
            </p>
          </div>

          {/* Issue Summary Card */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-left text-xs space-y-2 max-w-md mx-auto">
            <div className="flex justify-between">
              <span className="text-slate-500">Category:</span>
              <span className="font-semibold text-slate-800">{submittedIssue.category}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Location:</span>
              <span className="font-semibold text-slate-800">{submittedIssue.location}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Priority:</span>
              <span className="font-semibold text-slate-800">{submittedIssue.priority}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Initial Status:</span>
              <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold">
                {submittedIssue.status}
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={() => setActiveTab('issues')}
              className="w-full sm:w-auto px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-sm transition-all flex items-center justify-center gap-2"
            >
              <ListFilter className="w-4 h-4" />
              <span>Track in View Issues</span>
            </button>
            <button
              onClick={resetForm}
              className="w-full sm:w-auto px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-sm transition-all"
            >
              Submit Another Report
            </button>
          </div>
        </div>
      ) : (
        /* Report Form */
        <form onSubmit={handleSubmit} className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm space-y-6">
          {/* AI Helper Banner */}
          {aiSuggestion && (
            <div className="bg-indigo-50/80 border border-indigo-200 p-4 rounded-xl flex items-start justify-between gap-4 text-xs sm:text-sm">
              <div className="flex items-start space-x-3">
                <div className="p-1.5 bg-indigo-600 text-white rounded-lg mt-0.5">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-semibold text-indigo-950 flex items-center gap-2">
                    CivicFix AI Smart Assist ({aiSuggestion.confidence}% match)
                  </p>
                  <p className="text-indigo-800 mt-0.5">
                    Suggested Category: <strong className="text-indigo-950">{aiSuggestion.category}</strong> | Suggested Priority: <strong className="text-indigo-950">{aiSuggestion.priority}</strong>
                  </p>
                  <p className="text-indigo-600/90 text-xs mt-1 flex items-center gap-1">
                    <Building className="w-3.5 h-3.5 inline" /> Auto-Routes to: {aiSuggestion.suggestedDepartment}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={applyAiSuggestion}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg text-xs whitespace-nowrap transition-colors"
              >
                Auto-Apply Suggestions
              </button>
            </div>
          )}

          {/* Title input */}
          <div>
            <label className="block text-sm font-semibold text-slate-800 mb-1">
              Issue Short Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Overflowing waste bins near Central Park walkway"
              className={`w-full px-4 py-3 rounded-xl border text-sm text-slate-900 focus:outline-none focus:ring-2 transition-all ${
                errors.title
                  ? 'border-red-300 focus:ring-red-400 bg-red-50/30'
                  : 'border-slate-300 focus:ring-indigo-500 focus:border-indigo-500'
              }`}
            />
            {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
          </div>

          {/* Grid Category & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Category selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-800 mb-1">
                Category <span className="text-red-500">*</span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as IssueCategory)}
                className="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Priority selection */}
            <div>
              <label className="block text-sm font-semibold text-slate-800 mb-1">
                Priority Level <span className="text-red-500">*</span>
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as IssuePriority)}
                className="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
              >
                {priorities.map((p) => (
                  <option key={p} value={p}>
                    {p} Priority
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Location input */}
          <div>
            <label className="block text-sm font-semibold text-slate-800 mb-1 flex items-center justify-between">
              <span>
                Location / Landmark <span className="text-red-500">*</span>
              </span>
              <span className="text-xs font-normal text-slate-400 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-indigo-500" /> Be as specific as possible
              </span>
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g., Gate 3 entrance, opposite Science Hall entrance"
              className={`w-full px-4 py-3 rounded-xl border text-sm text-slate-900 focus:outline-none focus:ring-2 transition-all ${
                errors.location
                  ? 'border-red-300 focus:ring-red-400 bg-red-50/30'
                  : 'border-slate-300 focus:ring-indigo-500 focus:border-indigo-500'
              }`}
            />
            {errors.location && <p className="text-red-500 text-xs mt-1">{errors.location}</p>}
          </div>

          {/* Description input */}
          <div>
            <label className="block text-sm font-semibold text-slate-800 mb-1">
              Detailed Description <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the issue in detail (e.g. extent of damage, safety risk, time observed)..."
              className={`w-full px-4 py-3 rounded-xl border text-sm text-slate-900 focus:outline-none focus:ring-2 transition-all ${
                errors.description
                  ? 'border-red-300 focus:ring-red-400 bg-red-50/30'
                  : 'border-slate-300 focus:ring-indigo-500 focus:border-indigo-500'
              }`}
            />
            {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
          </div>

          {/* Reporter Name (Optional) */}
          <div>
            <label className="block text-sm font-semibold text-slate-800 mb-1 flex items-center justify-between">
              <span>Reporter Name / Role (Optional)</span>
              <span className="text-xs font-normal text-slate-400">Leave blank to report anonymously</span>
            </label>
            <input
              type="text"
              value={reporterName}
              onChange={(e) => setReporterName(e.target.value)}
              placeholder="e.g., Rahul Sharma (Student) or Local Resident"
              className="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Submit Action */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-100">
            <div className="text-xs text-slate-400 flex items-center gap-1">
              <HelpCircle className="w-4 h-4 text-slate-400" />
              <span>Status starts as 'Reported' and transitions as teams work.</span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-7 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-sm shadow-md transition-all disabled:opacity-50 flex items-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <PlusCircle className="w-4 h-4" />
                  <span>Submit Report</span>
                </>
              )}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
