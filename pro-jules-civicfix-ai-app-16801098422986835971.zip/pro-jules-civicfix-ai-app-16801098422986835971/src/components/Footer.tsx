import React from 'react';
import { Shield, Sparkles, Heart } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: 'home' | 'report' | 'issues' | 'dashboard') => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-sm border-t border-slate-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center space-x-2">
              <div className="bg-indigo-600 p-1.5 rounded-lg text-white">
                <Shield className="w-5 h-5" />
              </div>
              <span className="text-white font-bold text-lg tracking-tight">CivicFix AI</span>
            </div>
            <p className="text-slate-400 text-sm max-w-sm leading-relaxed">
              Report it. Track it. Improve your community. Empowering students and citizens with intelligent civic issue resolution.
            </p>
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-slate-800 border border-slate-700/60 rounded-full text-xs text-slate-300">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>AI-assisted categorization & status workflow</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-3">Quick Navigation</h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <button
                  onClick={() => setActiveTab('home')}
                  className="hover:text-indigo-400 transition-colors"
                >
                  Homepage
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('report')}
                  className="hover:text-indigo-400 transition-colors"
                >
                  Report an Issue
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('issues')}
                  className="hover:text-indigo-400 transition-colors"
                >
                  View Issues
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="hover:text-indigo-400 transition-colors"
                >
                  Issue Dashboard
                </button>
              </li>
            </ul>
          </div>

          {/* Issue Categories */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-3">Common Categories</h4>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li>• Garbage Overflow</li>
              <li>• Water Leakage</li>
              <li>• Broken Streetlights</li>
              <li>• Damaged Roads</li>
              <li>• Unclean Public Facilities</li>
            </ul>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500 gap-2">
          <p>© 2026 CivicFix AI – Community Issue Reporting System. College Project Edition.</p>
          <div className="flex items-center gap-1">
            <span>Built with</span>
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500 inline" />
            <span>for clean and safe communities.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
