import React from 'react';
import type { Issue, IssueStatus } from '../types/issue';
import { getCategoryEmoji, getStatusBadge, getPriorityBadge } from './IssueBadge';
import { MapPin, Calendar, ThumbsUp, Building, User, X, Check, Clock, AlertCircle } from 'lucide-react';

interface IssueDetailModalProps {
  issue: Issue | null;
  onClose: () => void;
  onStatusChange: (id: string, nextStatus: IssueStatus) => void;
  onUpvote: (id: string) => void;
}

export const IssueDetailModal: React.FC<IssueDetailModalProps> = ({
  issue,
  onClose,
  onStatusChange,
  onUpvote,
}) => {
  if (!issue) return null;

  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-slate-100 p-5 flex items-start justify-between z-10">
          <div className="flex items-center space-x-3">
            <span className="text-3xl">{getCategoryEmoji(issue.category)}</span>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono font-bold text-slate-500">{issue.id}</span>
                {getPriorityBadge(issue.priority)}
                {getStatusBadge(issue.status)}
              </div>
              <h2 className="text-xl font-bold text-slate-900 mt-0.5">{issue.title}</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6">
          {/* Metadata Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80 text-xs text-slate-600">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-indigo-500 shrink-0" />
              <span>
                <strong>Location:</strong> {issue.location}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-indigo-500 shrink-0" />
              <span>
                <strong>Reported:</strong> {formatDate(issue.createdAt)}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <User className="w-4 h-4 text-indigo-500 shrink-0" />
              <span>
                <strong>Reporter:</strong> {issue.reportedBy}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Building className="w-4 h-4 text-indigo-500 shrink-0" />
              <span>
                <strong>Dept:</strong> {issue.aiSuggestedDepartment || 'Municipal Services'}
              </span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Description</h3>
            <p className="text-slate-700 text-sm leading-relaxed bg-white p-4 rounded-xl border border-slate-200">
              {issue.description}
            </p>
          </div>

          {/* Status Progression Controls */}
          <div className="bg-gradient-to-r from-slate-50 to-indigo-50/50 p-5 rounded-2xl border border-indigo-100/80 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-900">
              Update Resolution Workflow Status
            </h3>
            <p className="text-xs text-slate-500">
              Track or simulate department progression for demonstration:
            </p>

            <div className="flex flex-wrap gap-2 pt-1">
              <button
                disabled={issue.status === 'Reported'}
                onClick={() => onStatusChange(issue.id, 'Reported')}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  issue.status === 'Reported'
                    ? 'bg-amber-500 text-white shadow-sm ring-2 ring-amber-300'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Set to Reported</span>
              </button>

              <button
                disabled={issue.status === 'In Progress'}
                onClick={() => onStatusChange(issue.id, 'In Progress')}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  issue.status === 'In Progress'
                    ? 'bg-indigo-600 text-white shadow-sm ring-2 ring-indigo-300'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Set to In Progress</span>
              </button>

              <button
                disabled={issue.status === 'Resolved'}
                onClick={() => onStatusChange(issue.id, 'Resolved')}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  issue.status === 'Resolved'
                    ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-300'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Check className="w-3.5 h-3.5" />
                <span>Set to Resolved</span>
              </button>
            </div>
          </div>

          {/* Timeline Audit Log */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Resolution Audit Timeline
            </h3>
            <div className="space-y-3 relative before:absolute before:inset-0 before:left-3.5 before:w-0.5 before:bg-slate-200">
              {issue.timeline.map((event) => (
                <div key={event.id} className="relative flex items-start space-x-3 pl-2">
                  <div
                    className={`w-3.5 h-3.5 rounded-full border-2 bg-white mt-1 shrink-0 z-10 ${
                      event.status === 'Resolved'
                        ? 'border-emerald-500 bg-emerald-500'
                        : event.status === 'In Progress'
                        ? 'border-indigo-500 bg-indigo-500'
                        : 'border-amber-500 bg-amber-500'
                    }`}
                  />
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 flex-1 text-xs space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-slate-800">{event.status}</span>
                      <span className="text-slate-400 text-[10px]">{formatDate(event.timestamp)}</span>
                    </div>
                    <p className="text-slate-600">{event.note}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-100 p-4 flex items-center justify-between">
          <button
            onClick={() => onUpvote(issue.id)}
            className="px-4 py-2 bg-white border border-slate-200 hover:border-slate-300 rounded-xl text-xs font-semibold text-slate-700 hover:text-indigo-600 flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <ThumbsUp className="w-4 h-4 text-indigo-500" />
            <span>Upvote ({issue.upvotes})</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold transition-colors"
          >
            Close Detail
          </button>
        </div>
      </div>
    </div>
  );
};
