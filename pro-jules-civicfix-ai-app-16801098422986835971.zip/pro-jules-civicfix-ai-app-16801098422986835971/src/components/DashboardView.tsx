import React from 'react';
import type { Issue, IssueStatus } from '../types/issue';
import { getCategoryEmoji, getStatusBadge, getPriorityBadge } from './IssueBadge';
import {
  TrendingUp,
  AlertCircle,
  Clock,
  CheckCircle2,
  PlusCircle,
  BarChart3,
  PieChart as PieIcon,
  RotateCcw,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

interface DashboardProps {
  issues: Issue[];
  onStatusChange: (id: string, newStatus: IssueStatus) => void;
  setActiveTab: (tab: 'home' | 'report' | 'issues' | 'dashboard') => void;
  onResetData: () => void;
}

export const DashboardView: React.FC<DashboardProps> = ({
  issues,
  onStatusChange,
  setActiveTab,
  onResetData,
}) => {
  const totalCount = issues.length;
  const reportedCount = issues.filter((i) => i.status === 'Reported').length;
  const inProgressCount = issues.filter((i) => i.status === 'In Progress').length;
  const resolvedCount = issues.filter((i) => i.status === 'Resolved').length;

  const resolutionRate =
    totalCount > 0 ? Math.round((resolvedCount / totalCount) * 100) : 0;

  // Category breakdown stats
  const categoryCounts: Record<string, number> = {};
  issues.forEach((i) => {
    categoryCounts[i.category] = (categoryCounts[i.category] || 0) + 1;
  });

  const recentIssues = [...issues]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-8 pb-12">
      {/* Dashboard Top Header */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-6 h-6 text-indigo-600" />
            <h1 className="text-2xl font-bold text-slate-900">CivicFix AI Command Dashboard</h1>
          </div>
          <p className="text-slate-500 text-sm mt-1">
            Real-time analytics and quick status management portal for administrators and citizens.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('report')}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-xs shadow-sm transition-all flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Report</span>
          </button>

          <button
            onClick={onResetData}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors flex items-center gap-1.5"
            title="Reset to original sample data"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Reset Demo Data</span>
          </button>
        </div>
      </div>

      {/* 4 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Total Issues
              </p>
              <h2 className="text-3xl font-black text-slate-900 mt-1">{totalCount}</h2>
            </div>
            <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
          <div className="mt-4 text-xs text-slate-500 flex items-center justify-between border-t border-slate-100 pt-3">
            <span>Overall Reported Baseline</span>
            <span className="font-semibold text-blue-600">100%</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Reported (Pending)
              </p>
              <h2 className="text-3xl font-black text-amber-600 mt-1">{reportedCount}</h2>
            </div>
            <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
              <AlertCircle className="w-6 h-6" />
            </div>
          </div>
          <div className="mt-4 text-xs text-slate-500 flex items-center justify-between border-t border-slate-100 pt-3">
            <span>Awaiting Department Review</span>
            <span className="font-semibold text-amber-600">
              {totalCount > 0 ? Math.round((reportedCount / totalCount) * 100) : 0}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                In Progress
              </p>
              <h2 className="text-3xl font-black text-indigo-600 mt-1">{inProgressCount}</h2>
            </div>
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
              <Clock className="w-6 h-6" />
            </div>
          </div>
          <div className="mt-4 text-xs text-slate-500 flex items-center justify-between border-t border-slate-100 pt-3">
            <span>Active Field Maintenance</span>
            <span className="font-semibold text-indigo-600">
              {totalCount > 0 ? Math.round((inProgressCount / totalCount) * 100) : 0}%
            </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Resolved
              </p>
              <h2 className="text-3xl font-black text-emerald-600 mt-1">{resolvedCount}</h2>
            </div>
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
              <CheckCircle2 className="w-6 h-6" />
            </div>
          </div>
          <div className="mt-4 text-xs text-slate-500 flex items-center justify-between border-t border-slate-100 pt-3">
            <span>Resolution Completion Rate</span>
            <span className="font-semibold text-emerald-600">{resolutionRate}%</span>
          </div>
        </div>
      </div>

      {/* Analytics Breakdown & Progress Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Category Breakdown list */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Category Volume & Progress</h2>
              <p className="text-xs text-slate-500">Distribution of issues by domain</p>
            </div>
            <PieIcon className="w-5 h-5 text-indigo-500" />
          </div>

          <div className="space-y-4">
            {Object.entries(categoryCounts).map(([cat, count]) => {
              const percentage = Math.round((count / totalCount) * 100);
              return (
                <div key={cat} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-medium text-slate-700">
                    <span className="flex items-center gap-1.5">
                      <span>{getCategoryEmoji(cat as any)}</span>
                      <span>{cat}</span>
                    </span>
                    <span>
                      {count} {count === 1 ? 'issue' : 'issues'} ({percentage}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Workflow Progression Box */}
        <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white p-6 rounded-2xl border border-slate-800 shadow-lg space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full text-xs font-medium">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Resolution Pipeline</span>
            </div>

            <h3 className="text-xl font-bold">Standard Status Progression</h3>
            <p className="text-slate-300 text-xs leading-relaxed">
              Every reported issue automatically travels through three distinct status milestones:
            </p>

            <div className="space-y-3 pt-2 text-xs">
              <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/80 flex items-center justify-between">
                <span className="font-semibold text-amber-400 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4" /> 1. Reported
                </span>
                <span className="text-slate-400">{reportedCount} active</span>
              </div>

              <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/80 flex items-center justify-between">
                <span className="font-semibold text-indigo-300 flex items-center gap-1.5">
                  <Clock className="w-4 h-4" /> 2. In Progress
                </span>
                <span className="text-slate-400">{inProgressCount} active</span>
              </div>

              <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/80 flex items-center justify-between">
                <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> 3. Resolved
                </span>
                <span className="text-slate-400">{resolvedCount} completed</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('issues')}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-xs transition-colors flex items-center justify-center gap-2"
          >
            <span>Manage Statuses in View Issues</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Recent Issues Table / Quick Action Card List */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Recent Activity Log</h2>
            <p className="text-xs text-slate-500">Most recently created civic reports</p>
          </div>
          <button
            onClick={() => setActiveTab('issues')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            View all ({totalCount}) <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 uppercase tracking-wider font-semibold">
                <th className="pb-3 font-semibold">ID & Category</th>
                <th className="pb-3 font-semibold">Title / Location</th>
                <th className="pb-3 font-semibold">Priority</th>
                <th className="pb-3 font-semibold">Status</th>
                <th className="pb-3 font-semibold text-right">Quick Transition</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {recentIssues.map((issue) => (
                <tr key={issue.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3.5 pr-3">
                    <div className="font-mono font-bold text-slate-900">{issue.id}</div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                      <span>{getCategoryEmoji(issue.category)}</span>
                      <span>{issue.category}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-3 max-w-xs">
                    <div className="font-semibold text-slate-900 truncate">{issue.title}</div>
                    <div className="text-[11px] text-slate-500 truncate mt-0.5">{issue.location}</div>
                  </td>
                  <td className="py-3.5 px-3">{getPriorityBadge(issue.priority)}</td>
                  <td className="py-3.5 px-3">{getStatusBadge(issue.status)}</td>
                  <td className="py-3.5 pl-3 text-right">
                    <div className="inline-flex items-center space-x-1">
                      {issue.status === 'Reported' && (
                        <button
                          onClick={() => onStatusChange(issue.id, 'In Progress')}
                          className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold rounded-lg text-[11px] transition-colors"
                        >
                          → Set In Progress
                        </button>
                      )}
                      {issue.status === 'In Progress' && (
                        <button
                          onClick={() => onStatusChange(issue.id, 'Resolved')}
                          className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold rounded-lg text-[11px] transition-colors"
                        >
                          → Set Resolved
                        </button>
                      )}
                      {issue.status === 'Resolved' && (
                        <span className="text-[11px] text-emerald-600 font-medium">✓ Closed</span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
