import React from 'react';
import type { Issue } from '../types/issue';
import {
  PlusCircle,
  ListFilter,
  LayoutDashboard,
  Sparkles,
  CheckCircle2,
  Clock,
  AlertCircle,
  ArrowRight,
  TrendingUp,
  BrainCircuit,
  Building2,
  Users,
} from 'lucide-react';

interface HomeViewProps {
  issues: Issue[];
  setActiveTab: (tab: 'home' | 'report' | 'issues' | 'dashboard') => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ issues, setActiveTab }) => {
  const totalCount = issues.length;
  const reportedCount = issues.filter((i) => i.status === 'Reported').length;
  const inProgressCount = issues.filter((i) => i.status === 'In Progress').length;
  const resolvedCount = issues.filter((i) => i.status === 'Resolved').length;

  return (
    <div className="space-y-12 pb-12">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-medium">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span>AI-Powered Citizen Engagement System</span>
          </div>

          <div className="space-y-2">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
              CivicFix <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">AI</span>
            </h1>
            <p className="text-xl sm:text-2xl font-semibold text-slate-300">
              "Report it. Track it. Improve your community."
            </p>
          </div>

          <p className="text-slate-400 text-base sm:text-lg leading-relaxed">
            Empower your campus and local neighborhood with a smart, streamlined problem reporting tool. Effortlessly submit reports for garbage overflow, water leakage, broken lights, and damaged roads, and monitor real-time repair progress.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={() => setActiveTab('report')}
              className="px-6 py-3.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-semibold rounded-xl shadow-lg shadow-indigo-500/25 flex items-center gap-2 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <PlusCircle className="w-5 h-5" />
              <span>Report an Issue</span>
            </button>

            <button
              onClick={() => setActiveTab('issues')}
              className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold rounded-xl flex items-center gap-2 transition-all"
            >
              <ListFilter className="w-5 h-5 text-indigo-400" />
              <span>View Issues</span>
            </button>

            <button
              onClick={() => setActiveTab('dashboard')}
              className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 hover:text-white font-semibold rounded-xl flex items-center gap-2 transition-all"
            >
              <LayoutDashboard className="w-5 h-5 text-indigo-400" />
              <span>Dashboard</span>
            </button>
          </div>
        </div>
      </section>

      {/* Quick Metrics Bar */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">Total Issues</p>
            <p className="text-3xl font-extrabold text-slate-900 mt-1">{totalCount}</p>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">Reported</p>
            <p className="text-3xl font-extrabold text-amber-600 mt-1">{reportedCount}</p>
          </div>
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <AlertCircle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">In Progress</p>
            <p className="text-3xl font-extrabold text-indigo-600 mt-1">{inProgressCount}</p>
          </div>
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">Resolved</p>
            <p className="text-3xl font-extrabold text-emerald-600 mt-1">{resolvedCount}</p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>
      </section>

      {/* Common Issue Types Section */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Supported Civic Categories</h2>
            <p className="text-slate-500 text-sm">Quickly log and resolve core public facility hazards.</p>
          </div>
          <button
            onClick={() => setActiveTab('report')}
            className="text-sm text-indigo-600 font-semibold hover:text-indigo-800 flex items-center gap-1"
          >
            Report now <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:border-indigo-300 transition-all group">
            <div className="text-3xl mb-3">🗑️</div>
            <h3 className="font-semibold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors">
              Garbage Overflow
            </h3>
            <p className="text-slate-500 text-sm mt-1">
              Unattended waste bins, dumped litter, or unhygienic public accumulation.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:border-indigo-300 transition-all group">
            <div className="text-3xl mb-3">💧</div>
            <h3 className="font-semibold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors">
              Water Leakage
            </h3>
            <p className="text-slate-500 text-sm mt-1">
              Broken supply pipes, burst mains, clogged drains, and standing water.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:border-indigo-300 transition-all group">
            <div className="text-3xl mb-3">💡</div>
            <h3 className="font-semibold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors">
              Broken Streetlights
            </h3>
            <p className="text-slate-500 text-sm mt-1">
              Dark pedestrian walkways, flickering bulbs, and electrical hazards.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:border-indigo-300 transition-all group">
            <div className="text-3xl mb-3">🛣️</div>
            <h3 className="font-semibold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors">
              Damaged Roads
            </h3>
            <p className="text-slate-500 text-sm mt-1">
              Deep potholes, cracked pavements, missing manhole covers, and road hazards.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:border-indigo-300 transition-all group">
            <div className="text-3xl mb-3">🧼</div>
            <h3 className="font-semibold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors">
              Unclean Public Facilities
            </h3>
            <p className="text-slate-500 text-sm mt-1">
              Restroom hygiene, broken seating, missing soap, and damaged park amenities.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm hover:border-indigo-300 transition-all group flex flex-col justify-center items-center text-center">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-full mb-2">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="font-semibold text-slate-900 text-base">Have another issue?</h3>
            <p className="text-slate-500 text-xs mt-1 mb-3">Our AI auto-categorizes custom descriptions.</p>
            <button
              onClick={() => setActiveTab('report')}
              className="text-xs bg-indigo-600 text-white font-medium px-4 py-2 rounded-lg hover:bg-indigo-700 transition-all"
            >
              Submit custom report
            </button>
          </div>
        </div>
      </section>

      {/* How it Works / AI Features */}
      <section className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-3xl p-8 sm:p-10 border border-slate-800 shadow-xl space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold">Smart Resolution Workflow</h2>
          <p className="text-slate-400 text-sm">
            How CivicFix AI streamlines issues from detection to resolution.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-800/60 p-6 rounded-2xl border border-slate-700/60 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
              1
            </div>
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <BrainCircuit className="w-5 h-5 text-indigo-400" /> AI Classification
            </h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              As you type your description, CivicFix AI analyzes key terms to auto-assign categories, departments, and priority levels.
            </p>
          </div>

          <div className="bg-slate-800/60 p-6 rounded-2xl border border-slate-700/60 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
              2
            </div>
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Building2 className="w-5 h-5 text-indigo-400" /> Dispatch & Tracking
            </h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Assigned municipal or campus departments update the issue status step-by-step: <span className="text-amber-300 font-medium">Reported</span> → <span className="text-indigo-300 font-medium">In Progress</span> → <span className="text-emerald-300 font-medium">Resolved</span>.
            </p>
          </div>

          <div className="bg-slate-800/60 p-6 rounded-2xl border border-slate-700/60 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
              3
            </div>
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-400" /> Community Transparency
            </h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Citizens upvote urgent issues, view timeline logs, and confirm completed maintenance for full accountability.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
