import type { IssueCategory, IssuePriority, IssueStatus } from '../types/issue';
import { AlertCircle, Clock, CheckCircle2 } from 'lucide-react';

export const getCategoryEmoji = (category: IssueCategory) => {
  switch (category) {
    case 'Garbage Overflow':
      return '🗑️';
    case 'Water Leakage':
      return '💧';
    case 'Broken Streetlights':
      return '💡';
    case 'Damaged Roads':
      return '🛣️';
    case 'Unclean Public Facilities':
      return '🧼';
    case 'Public Safety':
      return '⚠️';
    default:
      return '📌';
  }
};

export const getStatusBadge = (status: IssueStatus) => {
  switch (status) {
    case 'Reported':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
          <AlertCircle className="w-3.5 h-3.5" />
          <span>Reported</span>
        </span>
      );
    case 'In Progress':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800 border border-indigo-200">
          <Clock className="w-3.5 h-3.5 animate-pulse" />
          <span>In Progress</span>
        </span>
      );
    case 'Resolved':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Resolved</span>
        </span>
      );
  }
};

export const getPriorityBadge = (priority: IssuePriority) => {
  switch (priority) {
    case 'Urgent':
      return (
        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-red-100 text-red-800 border border-red-200 uppercase tracking-wider">
          Urgent
        </span>
      );
    case 'High':
      return (
        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-orange-100 text-orange-800 border border-orange-200 uppercase tracking-wider">
          High
        </span>
      );
    case 'Medium':
      return (
        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200 uppercase tracking-wider">
          Medium
        </span>
      );
    case 'Low':
      return (
        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700 border border-slate-200 uppercase tracking-wider">
          Low
        </span>
      );
  }
};
