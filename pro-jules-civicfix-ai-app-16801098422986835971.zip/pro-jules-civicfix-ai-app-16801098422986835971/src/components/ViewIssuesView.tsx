import React, { useState } from 'react';
import type { Issue, IssueStatus } from '../types/issue';
import { getCategoryEmoji, getStatusBadge, getPriorityBadge } from './IssueBadge';
import { IssueDetailModal } from './IssueDetailModal';
import {
  Search,
  Filter,
  PlusCircle,
  MapPin,
  Calendar,
  ThumbsUp,
  ArrowRight,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface ViewIssuesViewProps {
  issues: Issue[];
  onStatusChange: (id: string, newStatus: IssueStatus) => void;
  onUpvote: (id: string) => void;
  setActiveTab: (tab: 'home' | 'report' | 'issues' | 'dashboard') => void;
}

export const ViewIssuesView: React.FC<ViewIssuesViewProps> = ({
  issues,
  onStatusChange,
  onUpvote,
  setActiveTab,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [selectedPriority, setSelectedPriority] = useState<string>('All');
  const [activeModalIssue, setActiveModalIssue] = useState<Issue | null>(null);

  const categories = ['All', 'Garbage Overflow', 'Water Leakage', 'Broken Streetlights', 'Damaged Roads', 'Unclean Public Facilities', 'Public Safety', 'Other'];
  const statuses = ['All', 'Reported', 'In Progress', 'Resolved'];
  const priorities = ['All', 'Urgent', 'High', 'Medium', 'Low'];

  const filteredIssues = issues.filter((issue) => {
    const matchesSearch =
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.id.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'All' || issue.category === selectedCategory;
    const matchesStatus = selectedStatus === 'All' || issue.status === selectedStatus;
    const matchesPriority = selectedPriority === 'All' || issue.priority === selectedPriority;

    return matchesSearch && matchesCategory && matchesStatus && matchesPriority;
  });

  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedStatus('All');
    setSelectedPriority('All');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Community Reported Issues</h1>
          <p className="text-slate-500 text-sm mt-0.5">
            View, filter, and track real-time issue status across all sectors.
          </p>
        </div>
        <button
          onClick={() => setActiveTab('report')}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-sm shadow-sm transition-all flex items-center justify-center gap-2 self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Report New Issue</span>
        </button>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        {/* Search input */}
        <div className="relative">
          <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search issues by keyword, title, location, or ID (e.g., CF-2026-001)..."
            className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Filters dropdown row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Category Filter</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Status Filter</label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {statuses.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Priority Filter</label>
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {priorities.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Clear Filters helper */}
        {(searchQuery || selectedCategory !== 'All' || selectedStatus !== 'All' || selectedPriority !== 'All') && (
          <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>Showing {filteredIssues.length} matching result(s)</span>
            <button
              onClick={clearFilters}
              className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Clear Filters
            </button>
          </div>
        )}
      </div>

      {/* Issue Cards Grid */}
      {filteredIssues.length === 0 ? (
        <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-3">
          <div className="p-3 bg-slate-100 rounded-full w-12 h-12 text-slate-400 mx-auto flex items-center justify-center">
            <Filter className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-800">No matching issues found</h3>
          <p className="text-slate-500 text-sm max-w-sm mx-auto">
            Try adjusting your search term or filters to discover other community reports.
          </p>
          <button
            onClick={clearFilters}
            className="px-4 py-2 bg-indigo-50 text-indigo-600 font-semibold rounded-xl text-xs hover:bg-indigo-100 transition-colors"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredIssues.map((issue) => (
            <div
              key={issue.id}
              className="bg-white rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md hover:border-indigo-200 transition-all flex flex-col justify-between overflow-hidden group"
            >
              <div className="p-5 space-y-4">
                {/* Card Top Info */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl">{getCategoryEmoji(issue.category)}</span>
                    <div>
                      <span className="text-[11px] font-mono font-bold text-slate-400 block">
                        {issue.id}
                      </span>
                      <span className="text-xs font-semibold text-slate-600">{issue.category}</span>
                    </div>
                  </div>
                  {getPriorityBadge(issue.priority)}
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-slate-900 line-clamp-2 leading-snug group-hover:text-indigo-600 transition-colors">
                  {issue.title}
                </h3>

                {/* Description excerpt */}
                <p className="text-slate-600 text-xs line-clamp-2 leading-relaxed">
                  {issue.description}
                </p>

                {/* Location & Date */}
                <div className="space-y-1.5 pt-1 text-xs text-slate-500 border-t border-slate-100">
                  <div className="flex items-center space-x-1.5">
                    <MapPin className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                    <span className="truncate">{issue.location}</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>Logged on {formatDate(issue.createdAt)}</span>
                  </div>
                </div>

                {/* AI Department Badge */}
                {issue.aiSuggestedDepartment && (
                  <div className="px-2.5 py-1 bg-slate-50 border border-slate-200/80 rounded-lg text-[11px] text-slate-600 flex items-center justify-between">
                    <span className="truncate">Dept: {issue.aiSuggestedDepartment}</span>
                    <Sparkles className="w-3 h-3 text-indigo-500 shrink-0" />
                  </div>
                )}
              </div>

              {/* Card Footer Actions */}
              <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {getStatusBadge(issue.status)}
                  <button
                    onClick={() => onUpvote(issue.id)}
                    className="p-1.5 rounded-lg bg-white border border-slate-200 hover:border-slate-300 text-slate-600 hover:text-indigo-600 text-xs font-medium flex items-center gap-1 transition-colors"
                    title="Upvote issue urgency"
                  >
                    <ThumbsUp className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{issue.upvotes}</span>
                  </button>
                </div>

                <button
                  onClick={() => setActiveModalIssue(issue)}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition-colors"
                >
                  <span>Details & Status</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal Popup */}
      <IssueDetailModal
        issue={activeModalIssue}
        onClose={() => setActiveModalIssue(null)}
        onStatusChange={(id, status) => {
          onStatusChange(id, status);
          if (activeModalIssue) {
            setActiveModalIssue({
              ...activeModalIssue,
              status,
            });
          }
        }}
        onUpvote={(id) => {
          onUpvote(id);
          if (activeModalIssue) {
            setActiveModalIssue({
              ...activeModalIssue,
              upvotes: activeModalIssue.upvotes + 1,
            });
          }
        }}
      />
    </div>
  );
};
